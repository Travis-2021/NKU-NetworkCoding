//
// Created by 86137 on 2022/11/22.
//

#ifndef RELIABLEUDP_2_RUDP_H
#define RELIABLEUDP_2_RUDP_H

#include <iostream>

using namespace std;

static const int MSS = 1460; //最大报文段长度

#pragma pack (1)
//标志字段
typedef struct Flag {
    int ACK: 1;
    int RST: 1;
    int SYN: 1;
    int FIN: 1;
    int DES: 1;//文件描述信息

    void setACK() { ACK = 1; };

    void setRST() { RST = 1; };

    void setSYN() { SYN = 1; };

    void setFIN() { FIN = 1; };

    void setDES() { DES = 1; };

    bool isACK() const { return ACK; };

    bool isRST() const { return RST; };

    bool isSYN() const { return SYN; };

    bool isFIN() const { return FIN; };

    bool isDES() const { return DES; };

} Flag;

//伪首部
typedef struct PseudoHead {
    unsigned long seq{};          //序号         32bit
    unsigned long ack{};          //确认号       32bit
    struct Flag flag{};             //标志字段      8bit
    unsigned short dataLength;      //data长度      16bit
    unsigned short recvWinField{1};  //接收窗口      16bit
    unsigned short checkSum{};      //检验和        16bit

    void setSeq(int currentSeq);

    void setAck(int currentAck);

    void setDataLength(int length);

    void setRecvWinField(int winField);
} PseudoHead;

void PseudoHead::setSeq(int currentSeq) {
    this->seq = currentSeq;
}

void PseudoHead::setAck(int currentAck) {
    this->ack = currentAck;
}

void PseudoHead::setDataLength(int length) {
    this->dataLength = length;
}


void PseudoHead::setRecvWinField(int winField) {
    this->recvWinField = winField;
}


typedef struct Packet {
    struct PseudoHead head;
    char data[MSS]{};       //数据
    void setCheckSum();  //设置检验和
    bool checkSumValid();//检查检验和
    void setHead(struct PseudoHead head);

    void setData(char *sourceData);

} Packet;

#pragma pack ()


void Packet::setCheckSum() {
    unsigned long sum = 0;
    for (int i = 0; i < sizeof(struct Packet) / 2; i++) {
        sum += ((unsigned short *) this)[i];
    }
    while (sum >> 16) {
        sum = (sum & 0xffff) + (sum >> 16);
    }
    this->head.checkSum = ~sum;
}

bool Packet::checkSumValid() {
    unsigned long sum = 0;
    for (int i = 0; i < sizeof(struct Packet) / 2; i++) {
        sum += ((unsigned short *) this)[i];
    }
    while (sum >> 16) {
        sum = (sum & 0xffff) + (sum >> 16);
    }

    return sum == 0xffff;
//    return true;
}

void Packet::setHead(struct PseudoHead sourceHead) {
    this->head = sourceHead;
}

void Packet::setData(char *sourceData) {
    memset(this->data, '\0', MSS);
    memcpy(this->data, sourceData, this->head.dataLength);
}


#endif //RELIABLEUDP_2_RUDP_H
